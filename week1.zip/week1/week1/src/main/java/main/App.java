package main;
import java.util.Scanner;

/* Most java is learned through geeksforgeeks website and w3schools website */

public class App {

    /* creates the default instance */
    
    private Hedgehog currenthog = new Hedgehog("Pikseli", 5);

    /*
     * Method to create the menu and handle the user choices and the logic of each
     * choice
     */

    public void menu() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("1) Make the hedgehog talk, 2) Create a new hedgehog, 3) Make hedgehog run, 0) quit");
        System.out.println("");

        int choice = Integer.parseInt(scanner.nextLine());

        while (choice < 0 || choice > 4) {
            System.out.print("Invalid Choice, Try again.");
            menu();
        }

        switch (choice) {
            case 1:

                System.out.print("What does " + currenthog.name + " say?");
                String hoggySays = scanner.nextLine();
                if (hoggySays == "") {
                    System.out.print("I am " + currenthog.name + " and my age is " + currenthog.age + ", but could you still give me input values?");
                }
                System.out.print(hoggySays);
                menu();
            case 2:

                System.out.println("What is the name of the Hedgehog?");
                String newname = scanner.nextLine();
                System.out.println("What is the age of the hedgehog?");

                /* The error handling here is partially from chatGPT */

                int age = -1;
                try {
                    age = Integer.parseInt(scanner.nextLine());
                    if (age < 0) {
                        System.out.println("Wrong input value");
                    }
                    ;
                } catch (NumberFormatException e) {
                    System.out.println("Wrong input value");
                }
                currenthog.name = newname;
                currenthog.age = age;
                menu();

            case 3:
                System.out.println("How many laps?");
                int laps = -1;
                try {
                    laps = Integer.parseInt(scanner.nextLine());
                    if (laps < 0) {
                        System.out.println("Wrong input value");
                    }
                } catch (NumberFormatException e) {
                    System.out.println("Wrong input value");
                }
                currenthog.run(laps);
                menu();

            case 0:
                System.exit(0);

            default:
                System.out.println("Wrong input");

                scanner.close();
        }

    }

    public static void main(String[] args) {
        System.out.print(args[0]);
        App program = new App();
        program.menu();
    }

}
